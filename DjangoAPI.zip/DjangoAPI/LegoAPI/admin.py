from django.contrib import admin
from . models import LanguageFinder
# Register your models here.
admin.site.register(LanguageFinder)