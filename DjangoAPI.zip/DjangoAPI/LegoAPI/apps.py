from django.apps import AppConfig


class LegoapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LegoAPI'
