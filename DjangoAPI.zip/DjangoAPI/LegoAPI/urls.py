from django.urls import path,include
from . import views
from rest_framework import routers

router = routers.DefaultRouter()
router.register('LegoAPI', views.LanguageFinderView)
urlpatterns = [
    path('form/', views.FormView, name='form'),
    path('api/', include(router.urls)),
    #path('lang/', views.FormView, name='form'),
]

