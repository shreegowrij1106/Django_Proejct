from django.db import models
# Create your models here.
class LanguageFinder(models.Model):
    UID = models.CharField(max_length=10)
    FullName = models.CharField(max_length=30)
    Language_list = (('Arabic', 'Arabic'), ('Bulgarian', 'Bulgarian'), ('Bengali', 'Bengali'), ('Bosnian', 'Bosnian'),
                     ('Catalan', 'Catalan'), ('Czech', 'Czech'), ('Welsh', 'Welsh'), ('Danish', 'Danish'),
                     ('German', 'German'), ('Greek', 'Greek'), ('English', 'English'), ('Esperanto', 'Esperanto'),
                     ('Spanish', 'Spanish'), ('Estonian', 'Estonian'), ('Armenian', 'Armenian'),
                     ('Icelandic', 'Icelandic'), ('Hebrew', 'Hebrew'), ('Japanese', 'Japanese'),
                     ('Javanese', 'Javanese'), ('Kannada', 'Kannada'), ('Finnish', 'Finnish'), ('French', 'French'),
                     ('Gujarati', 'Gujarati'), ('Hindi', 'Hindi'), ('Croatian', 'Croatian'), ('Hungarian', 'Hungarian'),
                     ('Indonesian', 'Indonesian'), ('Italian', 'Italian'), ('Japanese', 'Japanese'), ('Khmer', 'Khmer'),
                     ('Korean', 'Korean'), ('Latin', 'Latin'), ('Latvian', 'Latvian'), ('Macedonian', 'Macedonian'),
                     ('Malayalam', 'Malayalam'), ('Marathi', 'Marathi'), ('Malay', 'Malay'), ('Myanmar', 'Myanmar'),
                     ('Nepali', 'Nepali'), ('Dutch', 'Dutch'), ('Norwegian', 'Norwegian'), ('Polish', 'Polish'),
                     ('Portuguese', 'Portuguese'), ('Romanian', 'Romanian'), ('Russian', 'Russian'),
                     ('Sinhala', 'Sinhala'), ('Slovak', 'Slovak'), ('Albanian', 'Albanian'), ('Serbian', 'Serbian'),
                     ('Sundanese', 'Sundanese'), ('Swedish', 'Swedish'), ('Swahili', 'Swahili'), ('Tamil', 'Tamil'),
                     ('Telugu', 'Telugu'), ('Thai', 'Thai'), ('Filipino', 'Filipino'), ('Turkish', 'Turkish'),
                     ('Ukrainian', 'Ukrainian'), ('Urdu', 'Urdu'), ('Vietnamese', 'Vietnamese'), ('Chinese', 'Chinese'),
                     ('Taiwan', 'Taiwan'), ('Mandarin', 'Mandarin'))
    Language_Choice = models.CharField(max_length=15, choices=Language_list)

    def __str__(self):
        return self.FullName
