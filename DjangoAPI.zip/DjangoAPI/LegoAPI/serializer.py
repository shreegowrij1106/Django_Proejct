from rest_framework import serializers
from .models import LanguageFinder

class LanguageFinderSerializers(serializers.ModelSerializer):
    class meta:
        model=LanguageFinder
        fields='__all__'