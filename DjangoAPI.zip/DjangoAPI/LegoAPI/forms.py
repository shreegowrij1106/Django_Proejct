from django import forms
from .models import LanguageFinder

class LanguageForm(forms.ModelForm):
    class Meta:
              model = LanguageFinder
              fields = "__all__"

    UID = forms.CharField(label='UID',max_length=8)
    FullName = forms.CharField(label='FullName',max_length=100)
    Language_Choice = forms.TypedChoiceField(choices=[('',''),('Arabic','Arabic'),('Bulgarian', 'Bulgarian'),('Bengali','Bengali'),('Bosnian', 'Bosnian'),('Catalan','Catalan'),('Czech', 'Czech'),('Welsh','Welsh'),('Danish', 'Danish'),('German','German'),('Greek', 'Greek'),('English','English'),('Esperanto', 'Esperanto'),('Spanish', 'Spanish'),('Estonian','Estonian'),('Armenian', 'Armenian'),('Icelandic','Icelandic'),('Hebrew', 'Hebrew'),('Japanese', 'Japanese'),('Javanese','Javanese'),('Kannada', 'Kannada'),('Finnish','Finnish'),('French', 'French'),('Gujarati','Gujarati'),('Hindi', 'Hindi'),('Croatian', 'Croatian'),('Hungarian','Hungarian'),('Indonesian', 'Indonesian'),('Italian','Italian'),('Japanese', 'Japanese'),('Khmer','Khmer'),('Korean', 'Korean'),('Latin','Latin'),('Latvian', 'Latvian'),('Macedonian','Macedonian'),('Malayalam', 'Malayalam'),('Marathi', 'Marathi'),('Malay','Malay'),('Myanmar', 'Myanmar'),('Nepali','Nepali'),('Dutch', 'Dutch'),('Norwegian','Norwegian'),('Polish', 'Polish'),('Portuguese','Portuguese'),('Romanian', 'Romanian'),('Russian','Russian'),('Sinhala', 'Sinhala'),('Slovak','Slovak'),('Albanian', 'Albanian'),('Serbian','Serbian'),('Sundanese', 'Sundanese'),('Swedish','Swedish'),('Swahili', 'Swahili'),('Tamil','Tamil'),('Telugu', 'Telugu'),('Thai','Thai'),('Filipino', 'Filipino'),('Turkish','Turkish'),('Ukrainian', 'Ukrainian'),('Urdu', 'Urdu'),('Vietnamese','Vietnamese'),('Chinese', 'Chinese'),('Taiwan','Taiwan'),('Mandarin', 'Mandarin')])