from django.shortcuts import render, redirect
from .forms import LanguageForm
from rest_framework import viewsets
from rest_framework.decorators import api_view
from django.core import serializers
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from .models import LanguageFinder
from .serializer import LanguageFinderSerializers
from gtts import gTTS
from playsound import playsound
import os

import pickle
import json
# import numpy as np
from sklearn import preprocessing
import pandas as pd
from django.contrib import messages


# Create your views here.

class LanguageFinderView(viewsets.ModelViewSet):
    queryset = LanguageFinder.objects.all()
    serializer_class = LanguageFinderSerializers


def MLlang(Name):
    try:
        model_name = 'xlnet-large-cased'
        # Load transformers config and set output_hidden_states to False
        config = XLNetConfig.from_pretrained(model_name)
        config.output_hidden_states = False
        # Load xlnet tokenizer
        tokenizer = XLNetTokenizer.from_pretrained(pretrained_model_name_or_path=model_name, config=config)
        from tensorflow.keras.models import model_from_json
        json_file = open('C:/Users/Arjun/Desktop/Hackathon/Hackathon/Lego2_model.json', 'r')
        loaded_model_json = json_file.read()
        json_file.close()
        loaded_model = model_from_json(loaded_model_json)
        loaded_model.load_weights("C:/Users/Arjun/Desktop/Hackathon/Hackathon/Lego2_weights.h5")
        with open('C:/Users/Arjun/Desktop/Hackathon/Hackathon/Language_Code.json') as f:
            Language_Input = json.loads(f.read())
        Name = Name.lower()
        Name = Name.strip()
        a = tokenizer.encode(
            text=Name,
            add_special_tokens=True,
            max_length=10,
            truncation=True,
            padding=True,
            return_tensors='tf',
            return_token_type_ids=False,
            return_attention_mask=False,
            verbose=True)
        a_as_vector = tf.reshape(a, [-1])
        zero_padding = tf.zeros([1 * 10] - tf.shape(a_as_vector), dtype=a.dtype)
        a_reshape = tf.concat([a_as_vector, zero_padding], 0)
        a_reshape = tf.reshape(a_reshape, [1, 10])
        d = loaded_model.predict(a_reshape)
        c = np.argmax(d['gtts_language'])
        for key, info in Language_Input.items():
            if (info['Language_label'] == c):
                mLang = info['Language']
        return mLang

    except ValueError as e:
        return Response(e.args[0], status.HTTP_400_BAD_REQUEST)


def play(name, ln):
    speech = gTTS(text=name, lang=ln, slow=False)
    speech.save('Name.mp3')
    os.system("start Name.mp3")


def FormView(request):
    if request.method == 'POST':
        form = LanguageForm(request.POST or None)

        if form.is_valid():
            UID = form.cleaned_data['UID']
            FullName = form.cleaned_data['FullName']
            Language = form.cleaned_data['Language']
            result = MLlang(FullName)
            play(FullName, result)
            return render(request, 'MLlang.html', {"data": result})

    form = LanguageForm()
    return render(request, 'form.html', {'form': form})
